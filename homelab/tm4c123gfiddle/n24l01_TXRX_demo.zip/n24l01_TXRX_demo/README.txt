project is baselined from code by J.Losh

note:
	- added "--c99" flag to compiler
	