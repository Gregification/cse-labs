/*
 * common.h
 *
 *  Created on: Mar 30, 2025
 *      Author: turtl
 */

#ifndef SRC_COMMON_H_
#define SRC_COMMON_H_

#define BV(X) (1 << (X))

#endif /* SRC_COMMON_H_ */
