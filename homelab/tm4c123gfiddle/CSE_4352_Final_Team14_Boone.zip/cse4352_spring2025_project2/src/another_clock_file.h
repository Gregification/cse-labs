/*
 * another_clock_file.h
 *
 *  Created on: Feb 6, 2025
 *      Author: greg
 */

#ifndef SRC_ANOTHER_CLOCK_FILE_H_
#define SRC_ANOTHER_CLOCK_FILE_H_

#include <stdbool.h>

bool initSysClkTo40Mhz();
bool initSysClkTo66Mhz67();

#endif /* SRC_ANOTHER_CLOCK_FILE_H_ */
